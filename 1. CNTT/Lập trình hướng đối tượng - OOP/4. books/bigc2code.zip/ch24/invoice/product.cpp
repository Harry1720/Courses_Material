#include "product.h"

Product::Product(string d, double p)
{  
   description = d;
   price = p;
}
