CREATE TABLE Customer (Customer_Number INTEGER, Name CHAR(40), Address CHAR(40), City CHAR(30), State CHAR(2), Zip CHAR(10))
INSERT INTO Customer VALUES (3175, 'Sams Small Applicances', '100 Main Street', 'Anytown', 'CA', '98765')
INSERT INTO Customer VALUES (3176, 'Electronics Unlimited', '1175 Liberty Ave', 'Pleasantville', 'MI', '45066')
SELECT * FROM Customer
