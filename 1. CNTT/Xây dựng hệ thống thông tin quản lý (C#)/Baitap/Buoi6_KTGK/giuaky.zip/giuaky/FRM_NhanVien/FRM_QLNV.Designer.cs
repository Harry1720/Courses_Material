﻿namespace FRM_NhanVien
{
    partial class FRM_QLNV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblSoSanPham = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.txtHeSoLuong = new System.Windows.Forms.TextBox();
            this.txtLuongCoBan = new System.Windows.Forms.TextBox();
            this.txtSoNgayVang = new System.Windows.Forms.TextBox();
            this.txtSoSanPham = new System.Windows.Forms.TextBox();
            this.radNhanVienVanPhong = new System.Windows.Forms.RadioButton();
            this.radNhanVienSanXuat = new System.Windows.Forms.RadioButton();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.dtpNgayVaoLam = new System.Windows.Forms.DateTimePicker();
            this.chkNhanVienNu = new System.Windows.Forms.CheckBox();
            this.btnDongY = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Họ tên";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ngày sinh";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ngày vào làm";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(58, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Hệ số lương";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(58, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Lương căn bản";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(59, 448);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Số ngày vắng";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radNhanVienSanXuat);
            this.groupBox1.Controls.Add(this.radNhanVienVanPhong);
            this.groupBox1.Location = new System.Drawing.Point(118, 311);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(327, 106);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chọn loại nhân viên";
            // 
            // lblSoSanPham
            // 
            this.lblSoSanPham.AutoSize = true;
            this.lblSoSanPham.Location = new System.Drawing.Point(496, 401);
            this.lblSoSanPham.Name = "lblSoSanPham";
            this.lblSoSanPham.Size = new System.Drawing.Size(86, 16);
            this.lblSoSanPham.TabIndex = 7;
            this.lblSoSanPham.Text = "Số sản phẩm";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(182, 62);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(279, 22);
            this.txtHoTen.TabIndex = 1;
            // 
            // txtHeSoLuong
            // 
            this.txtHeSoLuong.Location = new System.Drawing.Point(182, 204);
            this.txtHeSoLuong.Name = "txtHeSoLuong";
            this.txtHeSoLuong.Size = new System.Drawing.Size(92, 22);
            this.txtHeSoLuong.TabIndex = 5;
            // 
            // txtLuongCoBan
            // 
            this.txtLuongCoBan.Location = new System.Drawing.Point(182, 255);
            this.txtLuongCoBan.Name = "txtLuongCoBan";
            this.txtLuongCoBan.ReadOnly = true;
            this.txtLuongCoBan.Size = new System.Drawing.Size(279, 22);
            this.txtLuongCoBan.TabIndex = 6;
            // 
            // txtSoNgayVang
            // 
            this.txtSoNgayVang.Location = new System.Drawing.Point(182, 445);
            this.txtSoNgayVang.Name = "txtSoNgayVang";
            this.txtSoNgayVang.Size = new System.Drawing.Size(92, 22);
            this.txtSoNgayVang.TabIndex = 10;
            // 
            // txtSoSanPham
            // 
            this.txtSoSanPham.Location = new System.Drawing.Point(602, 398);
            this.txtSoSanPham.Name = "txtSoSanPham";
            this.txtSoSanPham.Size = new System.Drawing.Size(92, 22);
            this.txtSoSanPham.TabIndex = 9;
            // 
            // radNhanVienVanPhong
            // 
            this.radNhanVienVanPhong.AutoSize = true;
            this.radNhanVienVanPhong.Location = new System.Drawing.Point(32, 31);
            this.radNhanVienVanPhong.Name = "radNhanVienVanPhong";
            this.radNhanVienVanPhong.Size = new System.Drawing.Size(154, 20);
            this.radNhanVienVanPhong.TabIndex = 7;
            this.radNhanVienVanPhong.TabStop = true;
            this.radNhanVienVanPhong.Text = "Nhân viên văn phòng";
            this.radNhanVienVanPhong.UseVisualStyleBackColor = true;
            this.radNhanVienVanPhong.CheckedChanged += new System.EventHandler(this.radLoaiNhanVien_CheckedChanged);
            // 
            // radNhanVienSanXuat
            // 
            this.radNhanVienSanXuat.AutoSize = true;
            this.radNhanVienSanXuat.Location = new System.Drawing.Point(32, 66);
            this.radNhanVienSanXuat.Name = "radNhanVienSanXuat";
            this.radNhanVienSanXuat.Size = new System.Drawing.Size(140, 20);
            this.radNhanVienSanXuat.TabIndex = 8;
            this.radNhanVienSanXuat.TabStop = true;
            this.radNhanVienSanXuat.Text = "Nhân viên sản xuất";
            this.radNhanVienSanXuat.UseVisualStyleBackColor = true;
            this.radNhanVienSanXuat.CheckedChanged += new System.EventHandler(this.radLoaiNhanVien_CheckedChanged);
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.Location = new System.Drawing.Point(182, 105);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(126, 22);
            this.dtpNgaySinh.TabIndex = 3;
            // 
            // dtpNgayVaoLam
            // 
            this.dtpNgayVaoLam.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayVaoLam.Location = new System.Drawing.Point(182, 156);
            this.dtpNgayVaoLam.Name = "dtpNgayVaoLam";
            this.dtpNgayVaoLam.Size = new System.Drawing.Size(126, 22);
            this.dtpNgayVaoLam.TabIndex = 4;
            // 
            // chkNhanVienNu
            // 
            this.chkNhanVienNu.AutoSize = true;
            this.chkNhanVienNu.Location = new System.Drawing.Point(499, 64);
            this.chkNhanVienNu.Name = "chkNhanVienNu";
            this.chkNhanVienNu.Size = new System.Drawing.Size(46, 20);
            this.chkNhanVienNu.TabIndex = 2;
            this.chkNhanVienNu.Text = "Nữ";
            this.chkNhanVienNu.UseVisualStyleBackColor = true;
            // 
            // btnDongY
            // 
            this.btnDongY.Location = new System.Drawing.Point(311, 483);
            this.btnDongY.Name = "btnDongY";
            this.btnDongY.Size = new System.Drawing.Size(150, 32);
            this.btnDongY.TabIndex = 11;
            this.btnDongY.Text = "Đồng ý";
            this.btnDongY.UseVisualStyleBackColor = true;
            this.btnDongY.Click += new System.EventHandler(this.btnDongY_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(228, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(317, 25);
            this.label8.TabIndex = 17;
            this.label8.Text = "NHẬP THÔNG TIN NHÂN VIÊN";
            // 
            // FRM_QLNV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 527);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnDongY);
            this.Controls.Add(this.chkNhanVienNu);
            this.Controls.Add(this.dtpNgayVaoLam);
            this.Controls.Add(this.dtpNgaySinh);
            this.Controls.Add(this.txtSoSanPham);
            this.Controls.Add(this.txtSoNgayVang);
            this.Controls.Add(this.txtLuongCoBan);
            this.Controls.Add(this.txtHeSoLuong);
            this.Controls.Add(this.txtHoTen);
            this.Controls.Add(this.lblSoSanPham);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FRM_QLNV";
            this.Text = "Quản lý thông tin nhân viên";
            this.Load += new System.EventHandler(this.FRM_QLNV_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblSoSanPham;
        private System.Windows.Forms.RadioButton radNhanVienSanXuat;
        private System.Windows.Forms.RadioButton radNhanVienVanPhong;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.TextBox txtHeSoLuong;
        private System.Windows.Forms.TextBox txtLuongCoBan;
        private System.Windows.Forms.TextBox txtSoNgayVang;
        private System.Windows.Forms.TextBox txtSoSanPham;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.DateTimePicker dtpNgayVaoLam;
        private System.Windows.Forms.CheckBox chkNhanVienNu;
        private System.Windows.Forms.Button btnDongY;
        private System.Windows.Forms.Label label8;
    }
}

