﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FRM_NhanVien.Class
{
    public class NhanVienSX : NhanVien
    {
        // Properties riêng
        public int SoNgayVang { get; set; }
        public int SoLuongSanPham { get; set; }
        public int DinhMucSanPham { get; private set; } = 1000; // Mặc định 1000
        public double DonGiaSanPham { get; private set; } = 10000; // Mặc định 10k/sp

        // Constructor
        public NhanVienSX(string hoTen, GioiTinh gioiTinh, DateTime ngaySinh, DateTime ngayVaoLam, double heSoLuong, int soNgayVang, int soLuongSanPham)
            : base(hoTen, gioiTinh, ngaySinh, ngayVaoLam, heSoLuong)
        {
            this.SoNgayVang = soNgayVang;
            this.SoLuongSanPham = soLuongSanPham;

            // Riêng NVSX, định mức vắng tăng 2 ngày
            this.DinhMucSoNgayVang += 2;
        }

        // Override phương thức tính thưởng
        public override double TinhThuong()
        {
            double tienThuong = 0;

            // Tính thưởng cơ bản dựa trên sản phẩm vượt định mức
            if (SoLuongSanPham > DinhMucSanPham)
            {
                tienThuong = (SoLuongSanPham - DinhMucSanPham) * DonGiaSanPham * 0.05;
            }

            // Nếu số ngày vắng > định mức, giảm tiền thưởng
            if (SoNgayVang > DinhMucSoNgayVang)
            {
                int soNgayVangVuot = SoNgayVang - DinhMucSoNgayVang;
                double tienPhat = soNgayVangVuot * (tienThuong * 0.01);
                tienThuong -= tienPhat;
            }

            return tienThuong;
        }

        // Override phương thức tính lương
        public override double TinhLuong()
        {
            return (LuongCoBan * HeSoLuong) + TinhThuong();
        }

        // Ghi đè ToString để thêm thông tin riêng
        public override string ToString()
        {
            return base.ToString() + "\n" +
                   "Loại nhân viên: Nhân viên sản xuất";
        }
    }
}
