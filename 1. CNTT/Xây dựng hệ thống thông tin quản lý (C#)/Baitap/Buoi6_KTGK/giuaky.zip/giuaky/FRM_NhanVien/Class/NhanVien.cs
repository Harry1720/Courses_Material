﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FRM_NhanVien.Class
{
    public enum GioiTinh { Nam, Nu }

    public abstract class NhanVien
    {
        public string HoTen { get; set; }
        public GioiTinh GioiTinh { get; set; }
        public DateTime NgaySinh { get; set; }
        public DateTime NgayVaoLam { get; set; }
        public double HeSoLuong { get; set; }

        public static double LuongCoBan { get; set; } = 1050000; // mặc định = 1050000

        public virtual int DinhMucSoNgayVang { get; protected set; } = 3; // mặc định = 3 ngày

        public int ThamNien
        {
            get { return DateTime.Now.Year - NgayVaoLam.Year; }
        }

        // Constructor
        public NhanVien(string hoTen, GioiTinh gioiTinh, DateTime ngaySinh, DateTime ngayVaoLam, double heSoLuong)
        {
            HoTen = hoTen;
            GioiTinh = gioiTinh;
            NgaySinh = ngaySinh;
            NgayVaoLam = ngayVaoLam;
            HeSoLuong = heSoLuong;
        }

        // Các phương thức trừu tượng, buộc các lớp con phải override lại
        public abstract double TinhThuong();
        public abstract double TinhLuong();

        // Ghi đè phương thức ToString() để hiển thị thông tin chung
        public override string ToString()
        {
            return $"Thông tin lương của {HoTen}, Giới tính: {GioiTinh}\n" +
                   $"Ngày sinh: {NgaySinh:dd/MM/yyyy}, Ngày vào làm: {NgayVaoLam:dd/MM/yyyy}\n" +
                   $"Hệ số lương: {HeSoLuong:F2}";
        }
    }
}
