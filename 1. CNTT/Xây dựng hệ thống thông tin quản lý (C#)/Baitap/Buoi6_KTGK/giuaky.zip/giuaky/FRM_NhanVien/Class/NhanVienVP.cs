﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FRM_NhanVien.Class
{
    public class NhanVienVP : NhanVien
    {
        // Properties riêng
        public int SoNgayVang { get; set; }
        public double DonGiaPhat { get; private set; } = 100000; // Mặc định 100k/ngày

        // Constructor
        public NhanVienVP(string hoTen, GioiTinh gioiTinh, DateTime ngaySinh, DateTime ngayVaoLam, double heSoLuong, int soNgayVang)
            : base(hoTen, gioiTinh, ngaySinh, ngayVaoLam, heSoLuong)
        {
            this.SoNgayVang = soNgayVang;
        }

        // Phương thức riêng để tính tiền phạt
        public double TinhPhat()
        {
            if (SoNgayVang > DinhMucSoNgayVang)
            {
                return (SoNgayVang - DinhMucSoNgayVang) * DonGiaPhat;
            }
            return 0;
        }

        // Override phương thức tính thưởng
        public override double TinhThuong()
        {
            // 10% của (Lương cơ bản * Hệ số lương)
            return (LuongCoBan * HeSoLuong) * 0.1;
        }

        // Override phương thức tính lương
        public override double TinhLuong()
        {
            double luongCoSo = LuongCoBan * HeSoLuong;
            return luongCoSo + TinhThuong() - TinhPhat();
        }

        // Ghi đè ToString để thêm thông tin riêng
        public override string ToString()
        {
            return base.ToString() + "\n" +
                   "Loại nhân viên: Nhân viên văn phòng";
        }
    }
}
