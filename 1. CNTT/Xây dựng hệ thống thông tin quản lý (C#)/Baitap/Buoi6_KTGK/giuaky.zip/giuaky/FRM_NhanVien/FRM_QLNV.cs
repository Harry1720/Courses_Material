﻿using FRM_NhanVien.Class;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FRM_NhanVien
{
    public partial class FRM_QLNV : Form
    {
        public FRM_QLNV()
        {
            InitializeComponent();
        }
        private void FRM_QLNV_Load(object sender, EventArgs e)
        {
            // Thiết lập giá trị mặc định
            txtLuongCoBan.Text = NhanVien.LuongCoBan.ToString("N0");
            dtpNgaySinh.Value = new DateTime(2000, 1, 1);
            dtpNgayVaoLam.Value = DateTime.Today;
            radNhanVienVanPhong.Checked = true; // Chọn NVVP mặc định
        }

        private void radLoaiNhanVien_CheckedChanged(object sender, EventArgs e)
        {
            if (radNhanVienSanXuat.Checked)
            {
                lblSoSanPham.Visible = true;
                txtSoSanPham.Visible = true;
            }
            // (chọn nhân viên văn phòng)
            else
            {
                lblSoSanPham.Visible = false;
                txtSoSanPham.Visible = false;
            }
        }

        private void btnDongY_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Vui lòng nhập họ tên nhân viên!", "Thiếu thông tin", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHoTen.Focus();
                return;
            }

            try
            {
                string hoTen = txtHoTen.Text;
                GioiTinh gioiTinh = chkNhanVienNu.Checked ? GioiTinh.Nu : GioiTinh.Nam;
                DateTime ngaySinh = dtpNgaySinh.Value;
                DateTime ngayVaoLam = dtpNgayVaoLam.Value;
                double heSoLuong = double.Parse(txtHeSoLuong.Text);
                int soNgayVang = int.Parse(txtSoNgayVang.Text);
                NhanVien.LuongCoBan = double.Parse(txtLuongCoBan.Text.Replace(",", ""));

                NhanVien nv;

                if (radNhanVienVanPhong.Checked)
                {
                    nv = new NhanVienVP(hoTen, gioiTinh, ngaySinh, ngayVaoLam, heSoLuong, soNgayVang);
                }
                else
                {
                    int soSanPham = int.Parse(txtSoSanPham.Text);
                    nv = new NhanVienSX(hoTen, gioiTinh, ngaySinh, ngayVaoLam, heSoLuong, soNgayVang, soSanPham);
                }

                double luongTheoHeSo = NhanVien.LuongCoBan * nv.HeSoLuong;
                double tienThuong = nv.TinhThuong();
                double tienPhat = 0;
                double tongCong;

                if (nv is NhanVienVP nv_vp)
                {
                    // Nếu là NV Văn phòng, tính tiền phạt
                    tienPhat = nv_vp.TinhPhat();
                    tongCong = luongTheoHeSo + tienThuong - tienPhat;
                }
                else // Ngược lại là NV Sản xuất
                {
                    tongCong = luongTheoHeSo + tienThuong;
                }

                StringBuilder resultBuilder = new StringBuilder();
                resultBuilder.AppendLine(nv.ToString());
                resultBuilder.AppendLine($"Tiền thưởng: {tienThuong:N0} VNĐ");
                if(nv is NhanVienVP nvvp)
                {
                    resultBuilder.AppendLine($"Tiền phạt: {tienPhat:N0} VNĐ");
                }
                resultBuilder.AppendLine($"Tiền lương: {luongTheoHeSo:N0} VNĐ");
                resultBuilder.AppendLine($"Tổng cộng: {tongCong:N0} VNĐ");

                MessageBox.Show(resultBuilder.ToString(), "Thông tin lương nhân viên", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FormatException)
            {
                MessageBox.Show("Vui lòng nhập đúng định dạng số/không bỏ trống các ô!", "Lỗi định dạng", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã có lỗi xảy ra: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}