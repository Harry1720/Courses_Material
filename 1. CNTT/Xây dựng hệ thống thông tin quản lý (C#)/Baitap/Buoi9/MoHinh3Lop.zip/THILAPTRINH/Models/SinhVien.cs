﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace THILAPTRINH.Models
{
    class SinhVien
    {
        public int ID { get; set; }
        public string MaSV { get; set; }
        public string Ho { get; set; }
        public string TenSV { get; set; }
        public bool GioiTinh { get; set; }

        public SinhVien() { }

        public SinhVien(string maSV, string ho, string tenSV, bool gioiTinh)
        {
            MaSV = maSV;
            Ho = ho;
            TenSV = tenSV;
            GioiTinh = gioiTinh;
        }

    }
}
