﻿-- Tạo database
CREATE DATABASE QLSinhVien;
GO

-- Sử dụng database vừa tạo
USE QLSinhVien;
GO

-- Tạo bảng sinhvien
CREATE TABLE sinhvien (
    id INT IDENTITY(1,1) PRIMARY KEY,      -- Khóa chính, tự tăng
    ma_sv NVARCHAR(20) UNIQUE NOT NULL,    -- Mã sinh viên, độc nhất nhưng không phải khóa chính
	ho NVARCHAR(100) NOT NULL,
    ten NVARCHAR(100) NOT NULL,         -- Tên sinh viên
    gioi_tinh BIT NOT NULL                 -- Giới tính: 0 = Nam, 1 = Nữ
);

INSERT INTO sinhvien (ma_sv, ho, ten, gioi_tinh)
VALUES 
('sv001', 'Lâm Trí', 'Phúc', 0),
('sv002', 'Đặng Ngọc', 'Lan', 1);
GO

select * from sinhvien;


CREATE PROCEDURE sp_GetAllSinhVien
AS
BEGIN
    SELECT * FROM sinhvien
END

CREATE PROCEDURE sp_InsertSinhVien
    @ma_sv NVARCHAR(50),
    @ho NVARCHAR(100),
    @ten NVARCHAR(100),
    @gioi_tinh BIT
AS
BEGIN
    INSERT INTO sinhvien (ma_sv, ho, ten, gioi_tinh)
    VALUES (@ma_sv, @ho, @ten, @gioi_tinh);
END

CREATE PROCEDURE sp_UpdateSinhVien
    @ma_sv_cu NVARCHAR(50),
    @ma_sv_moi NVARCHAR(50),
    @ho NVARCHAR(100),
    @ten NVARCHAR(100),
    @gioi_tinh BIT
AS
BEGIN
    UPDATE sinhvien
    SET ma_sv = @ma_sv_moi,
        ho = @ho,
        ten = @ten,
        gioi_tinh = @gioi_tinh
    WHERE ma_sv = @ma_sv_cu;
END

CREATE PROCEDURE sp_DeleteSinhVien
    @ma_sv NVARCHAR(50)
AS
BEGIN
    DELETE FROM sinhvien
    WHERE ma_sv = @ma_sv;
END

