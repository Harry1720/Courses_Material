﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using THILAPTRINH.Models;

namespace THILAPTRINH.Data
{
    class SinhVienData
    {
        public static List<SinhVien> GetAll()
        {
            List<SinhVien> list = new List<SinhVien>();
            using (SqlConnection conn = Database.GetConnection())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_GetAllSinhVien", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new SinhVien
                    {
                        ID = (int)reader["id"],
                        MaSV = reader["ma_sv"].ToString(),
                        Ho = reader["ho"].ToString(),
                        TenSV = reader["ten"].ToString(),
                        GioiTinh = (bool)reader["gioi_tinh"]
                    });
                }
            }
            return list;
        }

        public static void Insert(SinhVien sv)
        {
            using (SqlConnection conn = Database.GetConnection())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_InsertSinhVien", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ma_sv", sv.MaSV);
                cmd.Parameters.AddWithValue("@ho", sv.Ho);
                cmd.Parameters.AddWithValue("@ten", sv.TenSV);
                cmd.Parameters.AddWithValue("@gioi_tinh", sv.GioiTinh);
                cmd.ExecuteNonQuery();
            }
        }

        public static void Update(string maSvCu, SinhVien sv)
        {
            using (SqlConnection conn = Database.GetConnection())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_UpdateSinhVien", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ma_sv_cu", maSvCu);
                cmd.Parameters.AddWithValue("@ma_sv_moi", sv.MaSV);
                cmd.Parameters.AddWithValue("@ho", sv.Ho);
                cmd.Parameters.AddWithValue("@ten", sv.TenSV);
                cmd.Parameters.AddWithValue("@gioi_tinh", sv.GioiTinh);
                cmd.ExecuteNonQuery();
            }
        }

        public static void Delete(string masv)
        {
            using (SqlConnection conn = Database.GetConnection())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_DeleteSinhVien", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ma_sv", masv);
                cmd.ExecuteNonQuery();
            }
        }

    }
}
