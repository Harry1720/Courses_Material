﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using THILAPTRINH.Data;
using THILAPTRINH.Models;

namespace THILAPTRINH
{
    public partial class frmSinhVien: Form
    {
        private List<SinhVien> danhSach;
        private int currentIndex = 0;
        private bool isAddingNew = false;
        private bool isEdit = false;

        public frmSinhVien()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            SetEditMode(false);
            danhSach = SinhVienData.GetAll();
            if (danhSach.Count > 0)
            {
                ShowSinhVien(0);
                currentIndex = 0;
            }
            if (danhSach.Count == 0)
                BlankInfo();
        }

        private void frmSinhVien_Load(object sender, EventArgs e)
        {
            SetEditMode(false);
            LoadData();
        }
        private void SetEditMode(bool isEditable)
        {
            txtMaSv.ReadOnly = !isEditable;
            txtHo.ReadOnly = !isEditable;
            txtTen.ReadOnly = !isEditable;
            chkGt.Enabled = isEditable;

            btnAdd.Enabled = !isEditable;
            btnEdit.Enabled = !isEditable;
            btnDel.Enabled = !isEditable;
            btnDontSave.Enabled = isEditable;
            btnSave.Enabled = isEditable;
        }
        private void ShowSinhVien(int index)
        {
            if (index >= 0 && index < danhSach.Count)
            {
                var sv = danhSach[index];
                txtMaSv.Text = sv.MaSV;
                txtHo.Text = sv.Ho;
                txtTen.Text = sv.TenSV;
                chkGt.Checked = sv.GioiTinh;
                lblStatus.Text = $"{index + 1}/{danhSach.Count}";
            }
        }
        private void BlankInfo()
        {
            txtMaSv.Clear();
            txtHo.Clear();
            txtTen.Clear();
            chkGt.Checked = false;
            lblStatus.Text = "--/--";
            txtMaSv.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SinhVien s = new SinhVien(txtMaSv.Text, txtHo.Text, txtTen.Text, chkGt.Checked);

                if (isAddingNew)
                {
                    SinhVienData.Insert(s);
                    MessageBox.Show("Thêm sinh viên thành công!");
                }
                else
                {
                    string ma_cu = danhSach[currentIndex].MaSV;
                    SinhVienData.Update(ma_cu, s);
                    MessageBox.Show("Sửa sinh viên thành công!");
                }

                LoadData();
                SetEditMode(false);
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                if (ex.Number == 2627 || ex.Number == 2601) 
                {
                    MessageBox.Show("Mã sinh viên đã tồn tại, vui lòng nhập mã khác!", "Lỗi trùng mã", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show("Lỗi cơ sở dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi không xác định: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnDontSave_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(
                "Bạn có chắc chắn muốn hủy?",
                "Cảnh báo",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                ShowSinhVien(0);
                SetEditMode(false);
                isEdit = false;
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SetEditMode(true);
            isAddingNew = true;
            BlankInfo();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            string ma = danhSach[currentIndex].MaSV;
            SinhVienData.Delete(ma);
            LoadData();
            if (danhSach.Count == 0)
                BlankInfo();

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            isAddingNew = false;
            SetEditMode(true);
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            currentIndex = 0;
            ShowSinhVien(currentIndex);
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            currentIndex = danhSach.Count - 1;
            ShowSinhVien(currentIndex);
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            if (currentIndex >= 0)
            {
                currentIndex--;
                ShowSinhVien(currentIndex);
            }
            else
            {
                MessageBox.Show("Đầu");
            }

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentIndex <= danhSach.Count - 1)
            {
                currentIndex++;
                ShowSinhVien(currentIndex);
            }
            else
            {
                MessageBox.Show("Cuối");
            }

        }

        private void frmSinhVien_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc chắn muốn thoát?",
                "Xác nhận thoát",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.No)
            {
                e.Cancel = true; // Hủy sự kiện đóng form
            }
        }
    }
}
